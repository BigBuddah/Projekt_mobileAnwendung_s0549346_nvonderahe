package com.example.nico.gpstest;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import static android.R.attr.path;


public class MainActivity extends AppCompatActivity {
    TextView tv_longitude;
    TextView tv_latitude;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        tv_longitude = (TextView) this.findViewById(R.id.longitude);
        tv_latitude = (TextView) this.findViewById(R.id.latitude);
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return;
            }
            //registriert des GPS-Provider, der alle 60s die Position abfragt
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 0, locationListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            if (l != null) {
                double latitude = l.getLatitude();
                double longitude = l.getLongitude();
                tv_longitude.setText("Longitude: " + longitude);
                tv_latitude.setText("Latitude: " + latitude);
                String string = String.valueOf(l.getTime()) + ":" + String.valueOf(l.getLatitude()) + "," + String.valueOf(l.getLongitude()) + ":";
                try {
                    FileOutputStream fou = openFileOutput("data.txt", MODE_APPEND);
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fou);
                    outputStreamWriter.write(string);
                    outputStreamWriter.close();
                    Toast.makeText(getBaseContext(),"Done writing SD 'data.txt'", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                        Toast.makeText(getBaseContext(), e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };

    @Override
      public boolean onCreateOptionsMenu(Menu menu) {
          super.onCreateOptionsMenu(menu);
          menu.add(Menu.NONE, 0, 0, "Exit");
          //menu.add(Menu.NONE, 1, 1, "Settings");
          //menu.add(Menu.NONE, 2, 2, "Other");
          return true;
      }
      @Override
      public boolean onOptionsItemSelected(MenuItem item){
          switch (item.getItemId()) {
          case 0:
              finish();
          }
          return false;
      }
      @Override
      public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

             // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // permission wurde gewährt
                } else {

                // permission nicht gewährt. Es wird eine Nachricht auf dem Bildschirm ausgegeben.
                    Toast.makeText(MainActivity.this, "Permission denied to use GPS", Toast.LENGTH_SHORT).show();
                }
                return;
            }

        }
    }

}